<!--
============================================
|       developed and code by ADR          |
|   https://www.instagram.com/artono_dr/   |
============================================
-->
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <link rel="shortcut icon" href="{{ asset('/images/ico-morowali.png') }}" />
    <!--====== Bootstrap ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/bootstrap.min.css">
    <!--====== Font Awesome ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/fonts/fontawesome/css/all.min.css">
    <!--====== Flaticon ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/fonts/flaticon/flaticon.css">
    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/animate.min.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/magnific-popup.min.css">
    <!--====== Slick Slider ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/slick.css">
    <!--====== Nice Select  ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/nice-select.css">
    <!--====== Default css ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/default.css">
    <!--====== Main Stylesheet ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/style.css">
    <!--====== Responsive Stylesheet ======-->
    <link rel="stylesheet" href="{{ asset('landing') }}/css/responsive.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        .font-c-1 {
            font-family: 'Montserrat', sans-serif;
        }
    </style>
</head>

<body>
    <!--======= Start Preloader =======-->
    <div class="preloader">
        <img class="preloader-image" width="60" src="{{ asset('/images/ico-morowali.png') }}" alt="preloader" />
    </div> <!-- /.preloader -->
    <!--======= End Preloader =======-->


    <!--====== Start Header Area ======-->
    <header class="header-area header-v6">
        <div class="header-navigation">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <!-- Brand Logo -->
                    <div class="col-xl-2 col-sm-5 col-5">
                        <div class="brand-logo">
                            <a href="{{ url('/') }}">
                                <img src="{{ asset('images/Logo-ico.png') }}" alt="logo v1" class="logo-v1"
                                    width="160">
                                <img src="{{ asset('images/Logo-ico-b.png') }}" alt="logo v2" class="logo-v2"
                                    width="160">
                            </a>
                        </div>
                    </div>
                    <!-- Desktop and Mobile Menu -->
                    <div class="col-xl-6 col-sm-1 col-2">
                        <div class="primary-menu">
                            <div class="nav-menu">
                                <!-- Navbar Close Icon -->
                                <div class="navbar-close">
                                    <div class="cross-wrap"><span class="top"></span><span class="bottom"></span>
                                    </div>
                                </div>
                                <nav class="main-menu">
                                    <ul>
                                        <li class="menu-item">
                                            <a href="{{ url('/') }}" class="nav-link"><i class="far fa-home"></i>
                                                Home</a>
                                        </li>
                                        {{-- <li class="menu-item menu-item-has-children">
                                                <a href="services.html" class="nav-link">Services</a>
                                                <ul class="sub-menu">
                                                    <li><a href="services.html">Our Services</a></li>
                                                    <li><a href="service-details.html">Service Details</a></li>
                                                </ul>
                                            </li> --}}

                                        <li class="menu-item">
                                            <a href="#panduan_section" class="nav-link">Panduan</a>
                                        </li>

                                        <li class="menu-item">
                                            <a href="#kontak_section" class="nav-link">Kontak</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-sm-6 col-5">
                        <div class="header-right">
                            <ul>
                                <li class="get-started-wrapper">
                                    {{-- <button type="button" onclick="initLogin()" class="filled-btn bg-clear-blue">
                                            Masuk <i class="fas fa-arrow-right"></i>
                                        </button> --}}
                                </li>
                                <li class="nav-tools d-xl-block"> {{-- d-none  --}}
                                    <a href="#" class="icon off-menu" id="btn_login">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </a>
                                    <div class="offcanvas-panel">
                                        <div class="menu-overlay"></div>
                                        <div class="offcanvas-panel-inner">
                                            {{-- <div class="panel-logo">
                                                    <img src="{{ asset('landing') }}/img/logo-royal-blue.png" alt="Panel Logo">
                                                </div> --}}
                                            <div class="about-us-widget">
                                                <h5 class="panel-widget-title">Login</h5>

                                                <div class="contact-respond">
                                                    <div class="row">
                                                        @error('gagalLogin')
                                                            <div class="common-heading tagline-boxed m-b-70 text-center">
                                                                <span class="tagline text-danger"><strong>Gagal !</strong>
                                                                    {{ $message }}</span>
                                                            </div>
                                                        @enderror
                                                        @if (session('success'))
                                                            <span
                                                                class="tagline text-success">{{ session('success') }}</span>
                                                        @endif
                                                    </div>
                                                    <form class="row g-3" method="POST"
                                                        action="{{ route('login.gas') }}">
                                                        @csrf
                                                        <div class="row">
                                                            <div class="input-group col-md-12">
                                                                <input type="text" class="form-control"
                                                                    id="user_nip" placeholder="NIP" name="user_nip"
                                                                    required>
                                                                <label for="user_nip">NIP</label>
                                                            </div>
                                                            <div class="input-group col-md-12">
                                                                <input type="password" class="form-control"
                                                                    id="password" placeholder="Password"
                                                                    name="password" required>
                                                                <label for="password">Password</label>
                                                            </div>
                                                            <div class="input-group col-md-12">
                                                                <button type="submit" class="filled-btn">Masuk <i
                                                                        class="fas fa-arrow-right"></i></button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>

                                            </div>

                                            <a href="#" class="panel-close">
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="menu-toggle">
                                        <div class="menu-overlay"></div>
                                        <div class="nav-toggle">
                                            <div class="navbar-toggler float-end">
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- /.row -->
            </div> <!-- /.container-fluid -->
        </div> <!-- /.header-navigation -->
    </header> <!-- /.header-area -->
    <!--====== End Header Area ======-->
    <!--====== Start Hero Area ======-->
    <section class="hero-area hero-v6">
        <div class="hero-slider">

            <div class="hero-slide-single"
                style="background-image: url({{ asset('landing') }}/img/hero/header-1.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7 col-lg-8">
                            <div class="hero-content">
                                <div class="section-title section-title-white">
                                    <h1 class="" data-animation="fadeInUp" data-delay=".1s"
                                        style="line-height: 60px;">BMD 4.0 <br><span class="font-c-1"
                                            style="font-size: 30pt; color: rgb(240, 255, 36)">Kabupaten Morowali</span>
                                    </h1>
                                    <div class="section-title-quote" data-animation="fadeInUp" data-delay=".2s">
                                        <p>....................</p>
                                    </div>
                                    <div class="section-button-wrapper section-dual-button" data-animation="fadeInUp"
                                        data-delay=".3s">
                                        <span>
                                            <button type="button" onclick="initLogin()"
                                                class="filled-btn bg-clear-blue mb-20" style="padding: 6px 40px;">
                                                Masuk <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </span>
                                        <span class="play-video">

                                            {{-- <span onclick="initRegis()" class="hero-btn mb-20 mt-10">
                                                Daftar
                                            </span> --}}

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="hero-slide-single"
                style="background-image: url({{ asset('landing') }}/img/hero/Header2.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7 col-lg-8">
                            <div class="hero-content">
                                <div class="section-title section-title-white">
                                    <h1 class="" data-animation="fadeInUp" data-delay=".1s"
                                        style="line-height: 60px;">BMD 4.0 <br><span class="font-c-1"
                                            style="font-size: 30pt; color: rgb(240, 255, 36)">Kabupaten Morowali</span>
                                    </h1>
                                    <div class="section-title-quote" data-animation="fadeInUp" data-delay=".2s">
                                        <p>....................</p>
                                    </div>
                                    <div class="section-button-wrapper section-dual-button" data-animation="fadeInUp"
                                        data-delay=".3s">
                                        <span>
                                            <button type="button" onclick="initLogin()"
                                                class="filled-btn bg-clear-blue " style="padding: 6px 40px;">
                                                Masuk <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </span>
                                        <span class="play-video">
                                            {{-- <span onclick="initRegis()" class="hero-btn mb-20 mt-10">
                                                    Daftar
                                                </span> --}}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- /.hero-slider -->
    </section> <!-- /.hero-area -->
    <!--====== End Hero Area ======-->
    <section class="our-team-area our-team-area-v2 pt-70 pb-50"
        style="background-image: url('{{ asset('landing/img/services/dots-pattern-bg.png') }}');">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col">
                    <div class="section-title text-center mb-67" style="">
                        <div class="section-heading-tag">
                            <span class="single-heading-tag">Team</span>
                        </div>
                        <h2>Pimpinan & Stakeholder</h2>
                    </div>
                </div> <!-- /.col-lg-8 -->
            </div> <!-- /.row -->
            <div class="team-member-content">
                <div class="row">

                    <div class="col-md-3"></div>

                    {{-- <div class="col-lg-3 col-md-6">
                        <div class="single-team-member single-team-member-v2 wow fadeInUp" data-wow-delay="00ms"
                            data-wow-duration="2000ms">
                            <div class="team-member-thumb">
                                <img src="{{ asset('landing/img/team/bupati.jpg') }}" alt="Team"
                                    style="min-height: 320px">
                            </div>
                            <div class="team-member-bio">
                                <h5 class="team-member-name">
                                    Ir.H.A Rachmansyah Ismail, M.Agr., MP
                                </h5>
                                <p class="team-member-role">
                                    BUPATI MOROWALI
                                </p>
                            </div>
                        </div>
                    </div> --}}

                    <div class="col-lg-3 col-md-6">
                        <div class="single-team-member single-team-member-v2 wow fadeInUp" data-wow-delay="00ms"
                            data-wow-duration="2000ms">
                            <div class="team-member-thumb">
                                <img src="https://morowalikab.go.id/portal_morowali/uploads/source/bupati.jpg" alt="Team"
                                    style="height: 330px">
                            </div>
                            <div class="team-member-bio">
                                <h5 class="team-member-name">
                                    Drs. Yusman Mahbub, M.Si
                                </h5>
                                <p class="team-member-role">
                                    PJ. BUPATI MOROWALI
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single-team-member single-team-member-v2 wow fadeInUp" data-wow-delay="00ms"
                            data-wow-duration="2000ms">
                            <div class="team-member-thumb">
                                <img src="{{ asset('landing/img/team/kaban1.jpg') }}" alt="Team"
                                    style="height: 330px">
                            </div>
                            <div class="team-member-bio">
                                <h5 class="team-member-name" style="font-size: 12pt">
                                    ALAMSYAH, S.STP, M.EC.DEV
                                </h5>
                                <p class="team-member-role">
                                    REFORMER / KEPALA BADAN
                                </p>
                            </div>
                        </div>
                    </div>

                </div> <!-- /.row -->
            </div> <!-- /.team-member-content -->
        </div> <!-- /.container -->
        <section id="panduan_section"></section>
    </section>
    <!--====== Start Our Services Area ======-->
    <section class="our-services our-services-v3 bg-light-magnolia pt-100 pb-60">
        <div class="container">
            {{-- <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <div class="section-title text-center mb-45">
                            <h2>Learn How to Move Faster</h2>
                            <div class="section-title-description">
                                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem aperiam eaque</p>
                            </div>
                        </div>
                    </div>
                </div> --}}
            <div class="row">
                <div class="col-lg-6">
                    <div class="single-service-box single-service-box-v3 wow fadeInUp" data-wow-delay="0.1s"
                        data-wow-duration="1500ms">
                        <div class="service-thumbnail">
                            <img src="{{ asset('landing/img/video1.jpg') }}" alt="Video">
                        </div>
                        <div class="service-box-content">
                            <h5 class="service-box-title">Video Tutorial</h5>
                            <p>Tonton video panduan penggunaan aplikasi BMD Morowali 4.0</p>
                            <div class="service-box-btn">
                                <a href="https://www.youtube.com/watch?v=bJFHw5P52aY" target="_blank">Lihat <i
                                        class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="single-service-box single-service-box-v3 wow fadeInUp" data-wow-delay="0.2s"
                        data-wow-duration="1500ms">
                        <div class="service-thumbnail">
                            <img src="{{ asset('landing/img/dok1.jpg') }}" alt="Modul">
                        </div>
                        <div class="service-box-content">
                            <h5 class="service-box-title">Modul Panduan</h5>
                            <p>Unduh modul panduan penggunaan aplikasi BMD Morowali 4.0</p>
                            <div class="service-box-btn">
                                <a href="{{ asset('Panduan_BMD_4.0_v1.pdf') }}">Unduh <i
                                        class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </section> <!-- /.our-services -->
    <!--====== End Our Services Area ======-->


    <!--======= Start Brands Slider =======-->
    <div class="brands-area bg-light-magnolia pt-20 pb-20 wow fadeInUp" data-wow-delay="0ms"
        data-wow-duration="2500ms">
        <div class="container">
            <div class="row">
                <div class="col-12 align-items-center text-center">
                    <img src="{{ asset('landing') }}/img/brand/kemenkeu1.png" width="320" alt="brand one">
                    <img src="{{ asset('landing') }}/img/brand/lan1.png" width="170" alt="brand two">
                    <img src="{{ asset('landing') }}/img/brand/logo-morowali.png" width="60" alt="brand three">

                </div>
            </div> <!-- /.row -->
        </div> <!-- /.container -->
        <section id="kontak_section"></section>
    </div> <!-- /.brands-area -->
    <!--======= End Brands Slider =======-->

    <section class="contact-area pt-70 pb-70">
        <div class="container">
            <div class="section-title mb-100">
                <div class="section-heading-tag">
                    <span class="single-heading-tag">Kontak</span>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="contact-area-content content-right-spacer">
                        <div class="info-iconic-boxes row">
                            <div class="col-md-4">
                                <div class="info-iconic-box wow fadeInUp" data-wow-delay="0.1s"
                                    data-wow-duration="1500ms">
                                    <div class="info-icon info-icon-gradient-1">
                                        <i class="fal fa-map-marker-alt"></i>
                                    </div>
                                    <div class="info-body">
                                        <h5 style="font-size: 15pt">Badan Pengelolaan Keuangan dan Aset Daerah</h5>
                                        {{-- <p>Kompleks Perkantoran Fonuasingko, Bente, Bungku Tengah, Kabupaten Morowali, Sulawesi Tengah 94973</p> --}}
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="info-iconic-box wow fadeInUp" data-wow-delay="0.2s"
                                    data-wow-duration="1500ms">
                                    <div class="info-icon info-icon-gradient-2">
                                        <i class="fal fa-envelope-open-text"></i>
                                    </div>
                                    <div class="info-body">
                                        <h5>Email</h5>
                                        <p><a
                                                href="mailto:admin@bpkad.morowalikab.go.id">admin@bpkad.morowalikab.go.id</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
<div style="display:none"><a href="http://ankararus.net" title="ankara escort">ankara escort</a> <a href="http://www.forumzevk.com/ad-category/cankaya-escort/" title="çankaya escort">çankaya escort</a> <a href="http://www.forumzevk.com" title="ankara escort">ankara escort</a> <a href="http://www.forumzevk.com/ad-category/eryaman-escort/" title="eryaman escort">eryaman escort</a> <a href="http://www.forumzevk.com/ad-category/turan-gunes-escort/" title="turan güneş escort">turan güneş escort</a></div>
                            <div class="col-md-4">
                                <div class="info-iconic-box wow fadeInUp" data-wow-delay="0.3s"
                                    data-wow-duration="1500ms">
                                    <div class="info-icon info-icon-gradient-3">
                                        <i class="fal fa-phone"></i>
                                    </div>
                                    <div class="info-body">
                                        <h5>Telepon/whatsapp</h5>
                                        <p><a href="https://wa.me/+6285255839287" target="_blank">+62
                                                852-5583-9287</a></p>
                                        <p><a href="https://wa.me/+6282293422625" target="_blank">+62
                                                822-9342-2625</a></p>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </section> <!-- /.contact-area -->

    <!--====== Start Subscribe Newsletter Area ======-->
    <section class="subscribe-newsletter bg-clear-blue wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms"
        style="min-height: 10px; margin-top: -10px">
        <div class="container">
            <div class="row align-items-center justify-content-center">

            </div>
        </div>
    </section>
    <!--====== End Subscribe Newsletter Area ======-->

    <!--begin::Modal-->
    {{-- <div class="modal fade" id="modal_user" tabindex="-1" role="dialog" aria-labelledby="User"
        aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <form id="form_user" method="POST" action="{{ route('regis.gas') }}">
                @csrf
                <div class="modal-content">
                    <div class="modal-header bg-light" id="regis_pos">
                        <h5 class="modal-title" id=""><i class="flaticon2-user"></i> <span
                                class="modal_label">Registrasi </span></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row contact-respond">
                            <div class="form-group col-md-6">
                                <label>NIP</label>
                                <input type="text" onchange="cekNip(this)" class="form-control" name="user_nip"
                                    id="user_nip" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Nama Lengkap</label>
                                <input type="text" class="form-control" name="user_nama" id="user_nama" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label>No Telepon</label>
                                <input type="text" class="form-control" name="user_tlp" id="user_tlp" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Alamat</label>
                                <input type="text" class="form-control" name="user_alamat" id="user_alamat"
                                    required>
                            </div>
                            <div class="input-group col-md-12">
                                <select class="form-control" name="user_opd" id="user_opd" style="width: 100%"
                                    required>
                                    <option value="">-- Pilih OPD --</option>
                                    @foreach ($opds as $opd)
                                        <option value="{{ $opd->opd_id }}">{{ $opd->opd_nama }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Password</label>
                                <input type="password" class="form-control" name="password_reg" id="password_reg"
                                    required>
                                <span class="text-danger label_pass" style="display: none">Password tidak cocok</span>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Ulangi Password</label>
                                <input type="password" class="form-control" name="password_confirm"
                                    id="password_confirm" required>
                                <span class="text-danger label_pass" style="display: none">Password tidak cocok</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Daftar</button>
                    </div>
                </div>
            </form>
        </div>
    </div> --}}
    <!--end::Modal-->

    <!--====== Start Footer Area ======-->
    <footer class="footer-area footer-area-v4 bg-dark-blue">
        <div class="container">
        </div> <!-- /.container -->
        <div class="footer-copyright-area wow fadeInDown" data-wow-delay="0.8s">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="footer-copyright text-center">
                            <p>&copy; {{ date('Y') }} <a href="#">Kabupaten Morowali</a></p>
                        </div>
                    </div>
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.footer-copyright-area -->
    </footer> <!-- /.footer-area -->
    <!--====== End Footer Area ======-->
    <!--======= Scroll To Top =======-->
    <a href="#" data-target="html" class="scroll-to-target scroll-to-top bg-clear-blue"><i
            class="fa fa-angle-up"></i></a>
    <!--====== Optional Javascript ======-->
    <script src="{{ asset('landing') }}/js/jquery-3.6.0.min.js"></script>
    <!--====== Popper JS ======-->
    <script src="{{ asset('landing') }}/js/popper.min.js"></script>
    <!--====== Bootstrap JS ======-->
    <script src="{{ asset('landing') }}/js/bootstrap.min.js"></script>
    <!--====== Slick Slider JS ======-->
    <script src="{{ asset('landing') }}/js/slick.min.js"></script>
    <!--====== Wow JS ======-->
    <script src="{{ asset('landing') }}/js/wow.js"></script>
    <!--====== Nice Select ======-->
    <script src="{{ asset('landing') }}/js/jquery.nice-select.min.js"></script>
    <!--====== Counter Up JS ======-->
    <script src="{{ asset('landing') }}/js/jquery.counterup.min.js"></script>
    <!--====== Magnific Popup JS ======-->
    <script src="{{ asset('landing') }}/js/jquery.magnific-popup.min.js"></script>
    <!--====== Waypoint JS ======-->
    <script src="{{ asset('landing') }}/js/jquery.waypoints.js"></script>
    <!--====== Main Script ======-->
    <script src="{{ asset('landing') }}/js/main.js"></script>
    <script>
        $(document).ready(function() {
            @error('gagalLogin')
                initLogin();
            @enderror
            @if (session('success'))
                initLogin();
            @endif
            // initRegis();
        });

        function initLogin() {
            $('#btn_login').trigger('click');
        }

        // function initRegis() {
        //     $('#modal_user').modal('show');
        // }

        $('#user_opd').on('change', function() {
            document.location = "#regis_pos";
        });

        async function cekNip(ob) {
            let nip = $(ob).val();
            let hasil = await sendAjax("{{ route('regis.cek.nip') }}", {
                nip: nip
            });
            if (hasil.cek) {
                $(ob).val('');
                alert("NIP /  Username sudah digunakan akun lain. Harap menggunakan NIP / Username yang lain");
            }
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        async function sendAjax(link, dataKirim = {}, metode = "POST") {
            return $.ajax({
                url: link,
                type: metode,
                data: dataKirim,
                success: function(res) {},
                error: function(e) {
                    alert("Terjadi kesalahan pada koneksi. Silahkan coba lagi");
                    console.log(e);
                }
            });
        }

        $('#form_user').on('submit', function(event) {
            let password_reg = $('#password_reg').val();
            let password_confirm = $('#password_confirm').val();
            if (password_reg != password_confirm) {
                event.preventDefault();
                $('.label_pass').show();
                $('#password_reg').val('');
                $('#password_confirm').val('');
            }
        })
    </script>
</body>

</html>
